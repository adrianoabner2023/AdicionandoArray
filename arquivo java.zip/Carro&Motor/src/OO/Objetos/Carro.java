package OO.Objetos;

public class Carro {

	Motor motor = new Motor();
	
	void acelerar() {
		if(motor.fatorinjecao < 2.6 ) {
		motor.fatorinjecao += 0.4;
		}
	}
	
	void frear() {
		if(motor.fatorinjecao > 0.5) {
			motor.fatorinjecao -=0.4;	
			
		}
		
		
	}
	void ligar() {
		
		motor.ligado = true;
	}

	void desligado() {
		
		motor.ligado = false;
	}

	boolean estaLigado() {
		
		return motor.ligado;
		
	}
}
