package Cliente;

import java.util.ArrayList;
import java.util.Scanner;

public class CompraTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String nomeproduto = null;
		int quantidade = 0;
		double preco = 0;
		int num  = 0;
	 
	do{
		
		System.out.println(" Pressione '1' para continuar ou '0' para sair");
		num = sc.nextInt();
		if (num !=0) {
		System.out.println("Me informe o nome do produto que vai comprar: ");
		nomeproduto = sc.next();
		System.out.println("Me informe a quantidade: ");
		quantidade= sc.nextInt();
		System.out.println("Me informe o valor do produto: ");
		preco = sc.nextDouble();
		Compra c1 = new Compra();
		
		c1.itens.add(new Itens(nomeproduto, quantidade, preco));

		System.out.println(c1.itens.size());
		System.out.println(c1.obterValorTotal());
	
		
		}else {
			
			System.out.println("Obrigado!!!");
		}
	}while(num!=0);
		

		
		System.out.printf("A quantidade de produtos inseridos foi de: "+quantidade);
	
			}

	
}
