package Cliente;

import java.util.ArrayList;

public class Itens {

	String nomedoproduto;
	int quantidade;
	double preco;
	
	
	Itens(String nome, int quantidade, double preco){
		
		this.nomedoproduto = nome;
		this.quantidade = quantidade;
		this.preco = preco;
		
		
	}
}
